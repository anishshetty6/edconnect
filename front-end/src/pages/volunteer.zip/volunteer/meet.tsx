"use client";

import { useParams } from "react-router-dom";
import VideoConference from "../../components/volunteer/VideoConference";
import { getApiUrl } from "../../utils/api";

const MeetPage = () => {
  const { roomId } = useParams<{ roomId: string }>();

  const fetchMeetingDetails = async () => {
    try {
      const response = await fetch(getApiUrl(`/api/meetings/${roomId}`));
      const data = await response.json();
      // Handle meeting data
    } catch (error) {
      // Handle error
    }
  };

  return (
    <div className="h-screen w-full overflow-hidden">
      <VideoConference roomID={roomId || ""} />
    </div>
  );
};

export default MeetPage;
